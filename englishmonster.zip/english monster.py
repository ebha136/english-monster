import json
with open("words_dictionary.json", "r") as read_file:
    print("Converting JSON encoded data into Python dictionary")
    dictionary = json.load(read_file)

def inDictionary(word):
    if word in dictionary:
        return True
    else:
        return False
    
import random, time
def intro():
    print("Welcome to English Monster! Your mission is to defeat a monster, with 100 HP, by using English words.")
    time.sleep(5)
    print("The longer the word, the higher the attack on the monster.")
    time.sleep(4)
    print("The monster can gain HP back anytime, so be careful!")
    time.sleep(4)
    print("Do NOT use the same word more than once, or you would be eliminated from the game IMMEDIATELY.")
    time.sleep(5)
    print("Type fast as well! If you take more than 10 seconds to type a word, the monster gains 20 HP!")
    time.sleep(5)
    print("Your mission is to destroy the monster by bringing its HP to 0. Good luck.")
    time.sleep(3)

def process():
    print("Loading...")
    time.sleep(3)
    monsterHP = 100
    wordlist = []
    while monsterHP > 0:
        i = random.randrange(1,4)
        x = random.randrange(1,4)
        start = 0
        start = time.time()
        word = str(input("Input a word: "))
        end = time.time()
        if word in wordlist:
            break
        elif (end - start) > 10:
            print("You went past the time limit of 10 seconds! The monster gains 20 HP!")
            monsterHP += 20
            print("HP left: ")
            print(("=" * monsterHP) + " " + str(monsterHP) + " HP\n")
        elif inDictionary(word) == False:
            print("INVALID PLAY: Word is not an English word.")
            continue
        elif (word not in wordlist) and (inDictionary(word) == True) and (end - start) <= 10:
            wordlist.append(word)
            monsterHP -= len(word)
            if monsterHP <= 0:
                break
            print("HP left: ")
            print(("=" * monsterHP) + " " + str(monsterHP) + " HP\n")
        
        if i == x:
            monsterHP += 10
            print("Oh my! The monster gained 10 HP!")
            print("HP left: ")
            print(("=" * monsterHP) + " " + str(monsterHP) + " HP\n")

    if monsterHP > 0 and (end - start) <= 10:
        print("You lost by typing a word that has been used before.")
        time.sleep(3)
        print("The monster had " + str(monsterHP) + " HP when you lost.")
        time.sleep(5)
        agree = str(input("Would you like to play this again? Say Y to yes and N to no: "))
        while not(agree == "Y" or agree == "N"):
            print("Invalid answer!")
            agree = str(input("Would you like to play this again? Say Y to yes and N to no: "))
        if agree == "Y":
            print("\n")
            process()
        elif agree == "N":
            print("If there were any bugs in this game, report them to me on discord at xeyso#7088.")
            time.sleep(5)
            print("Thanks for playing!")

    elif (end - start) > 10:
        print("You lost going past the time limit.")
        time.sleep(3)
        print("The monster had " + str(monsterHP) + " HP when you lost.")
        time.sleep(5)
        agree = str(input("Would you like to play this again? Say Y to yes and N to no: "))
        while not(agree == "Y" or agree == "N"):
            print("Invalid answer!")
            agree = str(input("Would you like to play this again? Say Y to yes and N to no: "))
        if agree == "Y":
            print("\n")
            process()
        elif agree == "N":
            print("If there were any bugs in this game, report them to me on discord at xeyso#7088.")
            time.sleep(5)
            print("Thanks for playing!")
                
    elif monsterHP <= 0 and (end - start) <= 10:
        print("Congrats! You crushed the monster completely!")
        time.sleep(4)
        agree = str(input("Would you like to play this again? Say Y to yes and N to no: "))
        while not(agree == "Y" or agree == "N"):
            print("Invalid answer!")
            agree = str(input("Would you like to play this again? Say Y to yes and N to no: "))
        if agree == "Y":
            print("\n")
            process()
        elif agree == "N":
            print("If there were any bugs in this game, report them to me on discord at xeyso#7088.")
            time.sleep(5)
            print("Thanks for playing!")


def em():
    intro()
    process()
    
